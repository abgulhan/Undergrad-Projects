To run program use the command:
python ./main.py <method = alphabeta, minimax> <filename>

Example: python ./main.py alphabeta input_22.txt

This program is compatible with Python3.7
